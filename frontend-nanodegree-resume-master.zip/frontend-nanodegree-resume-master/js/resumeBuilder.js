// Bio Information
//==========================================================================

var bio = {
    "name": "Saeed Al Mansour",
    "role": "Web Developer",
    "message": "Welcome to my website and I hope you enjoy reading my resume",
    "contacts": {
        "mobile": "0563593834",
        "email": "saeed.mq517@hotmail.com", 
        "github": "saeed517",
        "twitter": "@saeed517",
        "location": "audi Arabia, Riyadh"
    },
    "skills": [ "HTML", "CSS", "Javascript", "Python" ],
    "bioPic": "images/saeed4.jpg"
};

bio.display = function(){

    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    $("#header").prepend(formattedRole);

    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    $("#header").prepend(formattedName);

    var formattedMobile = HTMLmobile.replace(/%data%/, bio.contacts.mobile);
    $("#topContacts").append(formattedMobile);

    var formattedEmail = HTMLemail.replace(/%data%/, bio.contacts.email);
    $("#topContacts").append(formattedEmail);

    var formattedGithub = HTMLgithub.replace(/%data%/, bio.contacts.github);
    $("#topContacts").append(formattedGithub);



    var formattedBioPic = HTMLbioPic.replace("%data%", bio.bioPic)
    $("#header").append(formattedBioPic);

    var formattedWelcomeMessage = HTMLwelcomeMsg.replace("%data%", bio.message);
    $("#header").append(formattedWelcomeMessage);

    if(bio.skills.length > 0) {

        $("#header").append(HTMLskillsStart);

        var formattedSkill = HTMLskills.replace("%data%", bio.skills[0]);
        $("#skills").append(formattedSkill);

        formattedSkill = HTMLskills.replace("%data%", bio.skills[1]);
        $("#skills").append(formattedSkill);

        formattedSkill = HTMLskills.replace("%data%", bio.skills[2]);
        $("#skills").append(formattedSkill);

        formattedSkill = HTMLskills.replace("%data%", bio.skills[3]);
        $("#skills").append(formattedSkill);

    //footer contact info
    var formattedTwitter = HTMLtwitter.replace(/%data%/, bio.contacts.twitter);
    $("#topContacts").append(formattedTwitter);

    var formattedMobile = HTMLmobile.replace(/%data%/, bio.contacts.mobile);
    $("#footerContacts").append(formattedMobile);

    var formattedEmail = HTMLemail.replace(/%data%/, bio.contacts.email);
    $("#footerContacts").append(formattedEmail);

    var formattedGithub = HTMLgithub.replace(/%data%/, bio.contacts.github);
    $("#footerContacts").append(formattedGithub);

    var formattedTwitter = HTMLtwitter.replace(/%data%/, bio.contacts.twitter);
    $("#footerContacts").append(formattedTwitter);
    };

}
// Work History
//==========================================================================

var work = {
    "jobs": [
        {
            "employer": "Monash University",
            "title": "Industry experience project",
            "datesWorked": "July 2016 - Nov 2016",
            "location": "Melbourne, Caulfield",
            "description": "Overall responsibility for the successful initiation, planning, design, execution, monitoring, controlling and closure of a project."
        },
        {
            "employer": "Al-Rajhi Bank - Riada Co. (Al-Rajhi Project)",
            "title": "Customer Services",
            "datesWorked": "Sep 2009 - Oct 2010",
            "location": "Saudi Arabia, Riyadh",
            "description": "Responsibility: receive customers calls and help them over the phone. <br> Achievement: strong communication skills, solve problems, and deal with others."
        },
        {
            "employer": "Riada Co. (Al-Rajhi Project)",
            "title": "Etisal International in Customer Services and Banking Products",
            "datesWorked": "May 2009 - May 2009",
            "location": "Saudi Arabia, Riyadh",
            "description": "Receive customers calls and help them over the phone and gain a strong communication skills, solve problems, and deal with others."
        },
        {
            "employer": "Supply Company of Arabian trading supplies",
            "title": "Marketing and Sales",
            "datesWorked": "Mar 2009 - May 2009",
            "location": "Saudi Arabia, Riyadh",
            "description": "Records daily information of sales and report it to the department of sales."
        },
        {
            "employer": "Australian Computer Society (ACS).",
            "title": "ACS Membership",
            "datesWorked": "Jan 2016 - Currently",
            "location": "Australia, Melbourne",
            "description": "Researching, consulting, analysing and evaluating system program needs. <br> Identifying technology limitations and deficiencies in existing systems and associated processes, procedures and methods. <br> Testing, debugging, diagnosing and correcting errors and faults in an applications programming language within established testing protocols, guidelines and quality standards to ensure programs and applications perform to specification. <br> Writing and maintaining program code to meet system requirements, system designs and technical specifications in accordance with quality accredited standards. <br> Writing, updating and maintaining technical program, end user documentation and operational procedures."
        }
    ]
};

work.display = function(){

    for(job in work.jobs){
        $("#workExperience").append(HTMLworkStart);

        var formattedEmployer= HTMLworkEmployer.replace("%data%", work.jobs[job].employer);

        var formattedJobTitle= HTMLworkTitle.replace("%data%",work.jobs[job].title);

        var formattedEmployerTitle = formattedEmployer + formattedJobTitle;

        $(".work-entry:last").append(formattedEmployerTitle);

        var formattedDates= HTMLworkDates.replace("%data%",work.jobs[job].datesWorked);
        $(".work-entry:last").append(formattedDates);

        var formattedLocation= HTMLworkLocation.replace("%data%", work.jobs[job].location);
        $(".work-entry:last").append(formattedLocation);

        var formattedDescription= HTMLworkDescription.replace("%data%", work.jobs[job].description);
        $(".work-entry:last").append(formattedDescription);

    }
};

// Projects
//==========================================================================

var projects = {
    "projects":[
    {
        "title": "Project 1",
        "datesWorked": "Jan 2014 - Mar 2014",
        "description" : "It was a very good project with a lot of challenges. I gained skills of communication, trust others, get to know different personalities, different cultures, and different languages.",
        "images":["images/sport.jpg"]
    }
]
};

projects.display = function(){
    for(project in projects.projects){

        $("#projects").append(HTMLprojectStart);

        formattedProjectTitle= HTMLprojectTitle.replace("%data%",projects.projects[project].title);
            $(".project-entry:last").append(formattedProjectTitle);

        formattedProjectDates= HTMLprojectDates.replace("%data%",projects.projects[project].datesWorked);
            $(".project-entry:last").append(formattedProjectDates);

        if(projects.projects[project].images.length>0){

                for (image in projects.projects[project].images)
                formattedProjectImage= HTMLprojectImage.replace("%data%",projects.projects[project].images[image]);
            $(".project-entry:last").append(formattedProjectImage);

            }

        formattedProjectDescription= HTMLprojectDescription.replace("%data%",projects.projects[project].description);
            $(".project-entry:last").append(formattedProjectDescription);


        }
}

// Education
//==========================================================================

var education = {
    "schools": [
        {
            "name": "Monash University",
            "degree": "Master Degree",
            "location": "Melbourne, Caulfield",
            "majors": ["Business Information System"],
            "dates": "Dec 2016",
            "url": "https://www.monash.edu/"
        }
    ],
    "onlineCourses": [
        {
            "title": "Front-End Development Nanodegree",
            "school": "Udacity",
            "dates": "April 2017",
            "url": "https://www.udacity.com"
        }
    ]
};

education.display = function(){

    $("#education").append(HTMLschoolStart);

    for(school in education.schools){

        formattedSchoolName= HTMLschoolName.replace("%data%",education.schools[school].name);
            $(".education-entry:last").append(formattedSchoolName);

        formattedSchoolDegree= HTMLschoolDegree.replace("%data%",education.schools[school].degree);
            $(".education-entry:last").append(formattedSchoolDegree);

        formattedDates= HTMLschoolDates.replace("%data%",education.schools[school].datesAttended);
            $(".education-entry:last").append(formattedDates);

        formattedSchoolLocation= HTMLschoolLocation.replace("%data%",education.schools[school].location);
            $(".education-entry:last").append(formattedSchoolLocation);

        if(education.schools[school].majors.length>0){

                for (major in education.schools[school].majors){

                    formattedSchoolMajor= HTMLschoolMajor.replace("%data%",education.schools[school].majors[major]);

                    $(".education-entry:last").append(formattedSchoolMajor);
                }
        }

        }

$(".education-entry:last").append(HTMLonlineClasses);

    for(course in education.onlineCourses){

        formattedOnlineTitle= HTMLonlineTitle.replace("%data%",education.onlineCourses[course].title);
                    $(".education-entry:last").append(formattedOnlineTitle);

        formattedOnlineSchool= HTMLonlineSchool.replace("%data%",education.onlineCourses[course].school);
                    $(".education-entry:last").append(formattedOnlineSchool);

        formattedOnlineDates= HTMLonlineDates.replace("%data%",education.onlineCourses[course].dates);
                    $(".education-entry:last").append(formattedOnlineDates);

        formattedOnlineUrl= HTMLonlineURL.replace("%data%",education.onlineCourses[course].url);
                    $(".education-entry:last").append(formattedOnlineUrl);
    }

}

// Internationalize Name
//==========================================================================


// Capitalize all last name and ensure first letter in first name is capitalized
function inName(name){
    var name = bio.name;
    name = name.trim().split(" ");
    console.log(name);
    name[1]= name[1].toUpperCase();
    name[0]= name[0].slice(0,1).toUpperCase()+ name[0].slice(1).toLowerCase();

    return name[0]+" "+name[1];


}

$("#main").append(internationalizeButton)


// Clicks (Analytics)
//==========================================================================

$(document).click(function(loc){
    var x = loc.pageX;
    var y = loc.pageY;

    logClicks(x, y);});

// Call functions
//==========================================================================

bio.display();
work.display();
projects.display();
education.display();

$("#mapDiv").append(googleMap);



