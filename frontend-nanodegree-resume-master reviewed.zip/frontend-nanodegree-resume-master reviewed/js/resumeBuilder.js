// Bio Information
//==========================================================================

var bio = {
    "name": "Saeed Al Mansour",
    "role": "Web Developer",
    "contacts": {
        "mobile": "0563593834",
        "email": "saeed.mq517@hotmail.com", 
        "github": "saeed517",
        "twitter": "@saeed517",
        "location": "Saudi Arabia, Riyadh"
    },
    "welcomeMessage": "Welcome to my website and I hope you enjoy reading my resume",
    "skills": [ "HTML", "CSS", "Javascript", "Python" ],
    "biopic": "images/saeed4.jpg"
};

bio.display = function(){

    var formattedRole = HTMLheaderRole.replace("%data%", bio.role);
    var formattedName = HTMLheaderName.replace("%data%", bio.name);
    var formattedMobile = HTMLmobile.replace(/%data%/, bio.contacts.mobile);
    var formattedEmail = HTMLemail.replace(/%data%/, bio.contacts.email);
    var formattedGithub = HTMLgithub.replace(/%data%/, bio.contacts.github);
    var formattedTwitter = HTMLtwitter.replace("%data%", bio.contacts.twitter);
    var formattedLocation = HTMLlocation.replace("%data%", bio.contacts.location);
    

    $("#header").prepend(formattedName + formattedRole );

    $("#topContacts, #footerContacts").append( formattedMobile + formattedEmail + formattedGithub + formattedTwitter + formattedLocation);

    var formattedBioPic = HTMLbioPic.replace("%data%", bio.biopic);
    var formattedWelcomeMessage = HTMLwelcomeMsg.replace("%data%", bio.welcomeMessage);
    

    $("#header").append( formattedWelcomeMessage + formattedBioPic);

    $("#header").append(HTMLskillsStart);

    for (var i= 0 ; i<bio.skills.length ; i++){
        var formattedSkill = HTMLskills.replace("%data%", bio.skills[i]);
        $("#skills").append(formattedSkill);
    }
    
};

// Work History
//==========================================================================

var work = {
    "jobs": [
    {
        "employer": "Monash University",
        "title": "Industry experience project",
        "dates": "July 2016 - Nov 2016",
        "location": "Melbourne, Caulfield",
        "description": "Overall responsibility for the successful initiation, planning, design, execution, monitoring, controlling and closure of a project."
    },
    {
        "employer": "Al-Rajhi Bank - Riada Co. (Al-Rajhi Project)",
        "title": "Customer Services",
        "dates": "Sep 2009 - Oct 2010",
        "location": "Saudi Arabia, Riyadh",
        "description": "Responsibility: receive customers calls and help them over the phone. <br> Achievement: strong communication skills, solve problems, and deal with others."
    }
    ]
};

work.display = function(){

    $("#workExperience").append(HTMLworkStart);

    for (var job= 0 ; job < work.jobs.length ; job++){

        var formattedEmployer= HTMLworkEmployer.replace("%data%", work.jobs[job].employer);

        var formattedJobTitle= HTMLworkTitle.replace("%data%",work.jobs[job].title);

        var formattedEmployerTitle = formattedEmployer + formattedJobTitle;

        $(".work-entry:last").append(formattedEmployerTitle);

        var formattedDates= HTMLworkDates.replace("%data%",work.jobs[job].dates);
        $(".work-entry:last").append(formattedDates);

        var formattedLocation= HTMLworkLocation.replace("%data%", work.jobs[job].location);
        $(".work-entry:last").append(formattedLocation);

        var formattedDescription= HTMLworkDescription.replace("%data%", work.jobs[job].description);
        $(".work-entry:last").append(formattedDescription);

    }
};

// Projects
//==========================================================================

var projects = {
    "projects":[
    {
        "title": "Project 1",
        "dates": "Jan 2014 - Mar 2014",
        "description" : "It was a very good project with a lot of challenges. I gained skills of communication, trust others, get to know different personalities, different cultures, and different languages.",
        "images":["images/sport.jpg"]
    }
    ]
};

projects.display = function(){
    for (var project= 0 ; project < projects.projects.length ; project++){

        $("#projects").append(HTMLprojectStart);

        formattedProjectTitle= HTMLprojectTitle.replace("%data%",projects.projects[project].title);
        $(".project-entry:last").append(formattedProjectTitle);

        formattedProjectDates= HTMLprojectDates.replace("%data%",projects.projects[project].dates);
        $(".project-entry:last").append(formattedProjectDates);

        if(projects.projects[project].images.length>0){

            // for (image in projects.projects[project].images)
            for (var image = 0; image <projects.projects.length ; image++)
                formattedProjectImage= HTMLprojectImage.replace("%data%",projects.projects[project].images[image]);
            $(".project-entry:last").append(formattedProjectImage);

        }

        formattedProjectDescription= HTMLprojectDescription.replace("%data%",projects.projects[project].description);
        $(".project-entry:last").append(formattedProjectDescription);
    }
};

// Education
//==========================================================================

var education = {
    "schools": [
    {
        "name": "Monash University",
        "degree": "Master Degree",
        "location": "Melbourne, Caulfield",
        "majors": ["Business Information System"],
        "dates": "Dec 2016",
        "url": "https://www.monash.edu/"
    }
    ],
    "onlineCourses": [
    {
        "title": "Front-End Development Nanodegree",
        "school": "Udacity",
        "dates": "April 2017",
        "url": "https://www.udacity.com"
    }
    ]
};

education.display = function(){

    $("#education").append(HTMLschoolStart);
    for (var school = 0; school <education.schools.length ; school++){
    // for(school in education.schools){

        formattedSchoolName= HTMLschoolName.replace("%data%",education.schools[school].name);
        $(".education-entry:last").append(formattedSchoolName);

        formattedSchoolDegree= HTMLschoolDegree.replace("%data%",education.schools[school].degree);
        $(".education-entry:last").append(formattedSchoolDegree);

        formattedDates= HTMLschoolDates.replace("%data%",education.schools[school].datesAttended);
        $(".education-entry:last").append(formattedDates);

        formattedSchoolLocation= HTMLschoolLocation.replace("%data%",education.schools[school].location);
        $(".education-entry:last").append(formattedSchoolLocation);

        if(education.schools[school].majors.length>0){

           for (var major = 0; major < education.schools.length ; major++)
                // for (major in education.schools[school].majors)
            {

                formattedSchoolMajor= HTMLschoolMajor.replace("%data%",education.schools[school].majors[major]);

                $(".education-entry:last").append(formattedSchoolMajor);
            }
        }

    }

    $(".education-entry:last").append(HTMLonlineClasses);

    // for(course in education.onlineCourses)
    for (var course = 0; course < education.onlineCourses.length ; course++)
    {

        formattedOnlineTitle= HTMLonlineTitle.replace("%data%",education.onlineCourses[course].title);
        $(".education-entry:last").append(formattedOnlineTitle);

        formattedOnlineSchool= HTMLonlineSchool.replace("%data%",education.onlineCourses[course].school);
        $(".education-entry:last").append(formattedOnlineSchool);

        formattedOnlineDates= HTMLonlineDates.replace("%data%",education.onlineCourses[course].dates);
        $(".education-entry:last").append(formattedOnlineDates);

        formattedOnlineUrl= HTMLonlineURL.replace("%data%",education.onlineCourses[course].url);
        $(".education-entry:last").append(formattedOnlineUrl);
    }

};

// Internationalize Name
//==========================================================================


// Capitalize all last name and ensure first letter in first name is capitalized
function inName(name){
    var name = bio.name;
    name = name.trim().split(" ");
    console.log(name);
    name[1]= name[1].toUpperCase();
    name[0]= name[0].slice(0,1).toUpperCase()+ name[0].slice(1).toLowerCase();

    return name[0]+" "+name[1];


}

$("#main").append(internationalizeButton);


// Clicks (Analytics)
//==========================================================================

$(document).click(function(loc){
    var x = loc.pageX;
    var y = loc.pageY;

    logClicks(x, y);});

// Call functions
//==========================================================================

bio.display();
work.display();
projects.display();
education.display();

$("#mapDiv").append(googleMap);



